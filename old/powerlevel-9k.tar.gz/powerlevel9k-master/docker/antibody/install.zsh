curl -sL https://git.io/antibody | bash -s
