alias h='history'
alias hs='history | grep'
alias hsi='history | grep -i'
